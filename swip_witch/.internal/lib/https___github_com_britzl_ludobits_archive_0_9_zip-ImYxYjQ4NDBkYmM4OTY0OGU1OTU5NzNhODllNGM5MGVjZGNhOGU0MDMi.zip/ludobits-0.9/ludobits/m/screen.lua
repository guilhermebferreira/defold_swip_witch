local M = {}

M.width = sys.get_config("display.width")
M.height = sys.get_config("display.height")

M.window_width = M.width
M.window_height = M.height

return M